	<div class="row">
	<a href="<?php echo base_url() ?>index.php/add_blog/" class="btn btn-success a-btn-slide-text">
	<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
	<span><strong>Add Blog</strong></span>            
	</a>
	<a href="<?php echo base_url() ?>" class="btn btn-success a-btn-slide-text">
	<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
	<span><strong>Home Page</strong></span>            
	</a>
	<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Title</th>
                <th>Slug</th>
                <th>Description</th>
                <th>Image</th>
                <th>Status</th>
                <th>Created At</th>
				<th>Updated At</th>
				<th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		foreach($data as $key => $value){
		?>
            <tr>
                <td><?php echo $value['title']; ?></td>
                <td><?php echo $value['slug']; ?></td>
                <td><?php echo $value['description']; ?></td>
                <td><?php if(!empty($value['image'])){  $image= base_url().'uploads/'.$value['image']; echo "<img src='$image' style='width:100px'>"; } ?></td>
                <td><?php if(!empty($value['status'])){  echo 'Active';}else{ echo 'Inactive';} ?></td>
                <td><?php echo $value['created_at']; ?></td>
				<td><?php echo $value['update_at']; ?></td>
				<td>
					
					<a href="<?php echo base_url() ?>index.php/add_blog/<?php echo $value['id']; ?>" class="btn btn-primary a-btn-slide-text">
					<span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
					<span><strong>Edit</strong></span>            
					</a>
					<?php if(!empty($value['status'])){ ?>
					<a href="<?php echo base_url() ?>index.php/change_status/<?php echo $value['id']; ?>/0" class="btn btn-danger a-btn-slide-text">
					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
					<span><strong>Delete</strong></span>            
					</a>
					<?php } else{ ?>
					<a href="<?php echo base_url() ?>index.php/change_status/<?php echo $value['id']; ?>/1" class="btn btn-success a-btn-slide-text">
					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
					<span><strong>Add</strong></span>            
					</a>
					<?php } ?>

				</td>
            </tr>
		<?php
		}
		?>
        </tbody>
    </table>
	</div>
</div>

<style>
body{
background: #ccc;
}
#example_wrapper{
background: #fff;
padding-top: 20px;
margin-top:10px;
}
table{
    width:100%;
}
#example_filter{
    float:right;
}
#example_paginate{
    float:right;
}
label {
    display: inline-flex;
    margin-bottom: .5rem;
    margin-top: .5rem;
   
}
</style>
<script>
$(document).ready(function() {
    $('#example').DataTable(
        
         {     

      "aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
        "iDisplayLength": 25
       } 
        );
} );


function checkAll(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}
</script>