<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 function __Construct() {
			parent::__Construct();
			$this->load->model("blog_model");
			$this->load->database('');
		}


	public function index()
	{
		$data['data'] = $this->blog_model->select('blog','*');
		$this->load->view('welcome_message',$data);
	}

	public function blog_list(){
		$this->load->view('header');
		$data['data'] = $this->blog_model->select('blog','*');
		$this->load->view('blog_list',$data);
	}

	public function add_blog($id=''){
		$this->load->view('header');
		if(!empty($id)){
			$data['heading'] = 'Edit Blog';
			$data['data'] = $this->blog_model->select('blog','*',$id);
		}else{
			$data['heading'] = 'Add Blog';
		}
		
		$this->load->view('add_blog',$data);

		
	}

	public function change_status($blogid='',$status=''){
		$data['status'] = $status;
		$this->blog_model->insert_or_update('blog', $data,$blogid);
		redirect('blog_list', 'refresh');
	}

	public function submit_blog(){
		$array_return = array();
		$array_return['status'] = 'SUCCESS';
		$array_return['desc'] = 'SUCCESS';
		$this->load->helper(array('form'));
		$this->load->library('form_validation');

		$edit = $this->input->post('edit');
		
		$slug = $this->input->post('slug');
		
		if(empty($slug)){
			// replace non letter or digits by -
			$slug = preg_replace('~[^\pL\d]+~u', '-', $this->input->post('title'));
			// transliterate
			$slug = iconv('utf-8', 'us-ascii//TRANSLIT', $slug);
			// remove unwanted characters
			$slug = preg_replace('~[^-\w]+~', '', $slug);
			// trim
			$slug = trim($slug, '-');
			// remove duplicate -
			$slug = preg_replace('~-+~', '-', $slug);
			// lowercase
			$slug = strtolower($slug);
			$_POST['slug'] = $slug;
		}
		
		if(empty($edit)){
			$this->form_validation->set_rules('title', 'Title', 'required|is_unique[blog.title]');
		}else{
			$this->form_validation->set_rules('title', 'Title', 'required');
			//on updating removed unique check , but it sholud check if we update other blog title
		}
		$this->form_validation->set_rules('slug', 'Slug', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');

		$data_to_insert = array();
		$data_to_insert['title'] = $this->input->post('title');
		$data_to_insert['slug'] = $this->input->post('slug');
		$data_to_insert['description'] = $this->input->post('description');
		if(!empty($edit)){
			$data_to_insert['update_at'] = date('Y-m-d H:i:s');
		}

		if ($this->form_validation->run() == FALSE) {
			$array_return['status'] = 'ERROR';
			$array_return['desc'] = validation_errors();
		}
		else
		{
			if(empty($_FILES['image']['size'])){
				if(empty($edit)){
					$array_return['status'] = 'ERROR';
					$array_return['desc'] = "Please select a image to upload";
				}
			}
			else{
				

				// If all validation rules are passed then validate image and upload 
				//Image upload Starts Here
				$config['upload_path']   = './uploads/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg'; 
				$config['max_size']      = 100;
				$this->load->library('upload', $config);
				if ( ! $this->upload->do_upload('image')){
				$array_return['status'] = 'ERROR';
				$array_return['desc'] = $this->upload->display_errors();
				}else{
				$file_info = $this->upload->data();
				$img = $file_info['file_name']; 
				$data_to_insert['image'] = $img;
			}
		}
			//Image upload ends here
		}
		$this->blog_model->insert_or_update('blog', $data_to_insert,$edit);

		echo json_encode($array_return);
	}
}
