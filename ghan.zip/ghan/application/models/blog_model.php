<?php
class Blog_model extends CI_Model{
  /**
  * @desc load both db
  */
  function __construct(){
  parent::__Construct();
  }

  function insert_or_update($table,$data,$id=''){
	if(!empty($id)){
		$this->db->where('id',$id);
   		$this->db->update($table,$data);
	}else{
		$this->db->insert($table,$data);
	}
  }


  function select($table,$data,$id=''){
		$this->db->select($data);
		if(!empty($id)){
			$this->db->where('id',$id);
		}
		$query = $this->db->get($table);
		return $query->result_array();
  }


}

?>