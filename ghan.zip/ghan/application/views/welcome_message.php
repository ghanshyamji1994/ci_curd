<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<a href="<?php echo base_url() ?>index.php/add_blog/" class="btn btn-success a-btn-slide-text">
	<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
	<span><strong>Add Blog</strong></span>            
	</a>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.1.0/css/font-awesome.min.css"/>
<div class="container">

	<?php
	foreach($data as $key => $value){
	?>
  <div class="well">
      <div class="media">
      	<a class="pull-left" href="#">
    		
			<?php if(!empty($value['image'])){  $image= base_url().'uploads/'.$value['image']; echo "<img src='$image' class='media-object' style='width:100px'>"; } ?>
  		</a>
  		<div class="media-body">
    		<h4 class="media-heading"><?php echo $value['title']; ?></h4>
          
          <p><?php echo $value['description']; ?></p>
          
       </div>
    </div>
  </div>
  <?php
	}
 ?>


  
    </div>
  </div>
</div>