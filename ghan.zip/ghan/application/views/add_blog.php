	<div class="row">
	<a href="<?php echo base_url() ?>index.php/blog_list/" class="btn btn-success a-btn-slide-text">
	<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
	<span><strong>Added Blog List</strong></span>            
	</a>

	<a href="<?php echo base_url() ?>" class="btn btn-success a-btn-slide-text">
	<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
	<span><strong>Home Page</strong></span>            
	</a>
	<div class="container contact">
	
	<form method='post' id='create_blog' style='width:100%' enctype='multipart/form-data'action="<?php echo base_url(); ?>/index.php/submit_blog">
	<div class="row">

		<div class="col-md-3">
			<div class="contact-info">				
				<h2><?php echo $heading; ?></h2>
			</div>
		</div>
		
			<input type='hidden' name='edit' value='<?php if(!empty($data[0]['id'])){ echo $data[0]['id'];} ?>'>
		
			<div class="col-md-9">
				<div id='error_list' style='color:red'></div>
				<div class="contact-form">
					<div class="form-group">
					  <label class="control-label col-sm-2" for="fname">Title: <span style='color:red;font-weight:bold'>*</span></label>
					  <div class="col-sm-10">          
						<input type="text" class="form-control" placeholder="Enter Title" name="title" value='<?php if(!empty($data[0]['title'])){ echo $data[0]['title'];} ?>'>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-2" for="lname">Slug:</label>
					  <div class="col-sm-10">          
						<input type="text" class="form-control" placeholder="Enter Slug" name="slug" value='<?php if(!empty($data[0]['slug'])){ echo $data[0]['slug'];} ?>'>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-2" for="email">Description:<span style='color:red;font-weight:bold'>*</span></label>
					  <div class="col-sm-10">
						<textarea class="form-control" placeholder="Enter Description" name="description"><?php if(!empty($data[0]['description'])){ echo $data[0]['description'];} ?></textarea>
					  </div>
					</div>
					<div class="form-group">
					  <label class="control-label col-sm-2" for="comment">Image: <span style='color:red;font-weight:bold'>*</span></label>
					  

					  <div class="col-sm-10">
						<input type='file' name='image'>
						<br>
						<?php if(!empty($data[0]['image'])){ $path=base_url();echo "<img src='$path/uploads/".$data[0]['image']."' style='width:200px'>";} ?>
					  </div>

					</div>
					<div class="form-group">        
					  <div class="col-sm-offset-2 col-sm-10">
						<button type="submit" class="btn btn-default">Submit</button>
					  </div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

	</div>
</div>

<style>
body{
background: #ccc;
}
#example_wrapper{
background: #fff;
padding-top: 20px;
margin-top:10px;
}
table{
    width:100%;
}
#example_filter{
    float:right;
}
#example_paginate{
    float:right;
}
label {
    display: inline-flex;
    margin-bottom: .5rem;
    margin-top: .5rem;
   

}

	.contact{
		padding: 4%;
		height: 400px;
	}
	.col-md-3{
		background: #ff9b00;
		padding: 4%;
		border-top-left-radius: 0.5rem;
		border-bottom-left-radius: 0.5rem;
	}
	.contact-info{
		margin-top:10%;
	}
	.contact-info img{
		margin-bottom: 15%;
	}
	.contact-info h2{
		margin-bottom: 10%;
	}
	.col-md-9{
		background: #fff;
		padding: 3%;
		border-top-right-radius: 0.5rem;
		border-bottom-right-radius: 0.5rem;
	}
	.contact-form label{
		font-weight:600;
	}
	.contact-form button{
		background: #25274d;
		color: #fff;
		font-weight: 600;
		width: 25%;
	}
	.contact-form button:focus{
		box-shadow:none;
	}
</style>
<script>
$(document).ready(function (e) {
    $('#create_blog').on('submit',(function(e) {
        e.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: $(this).attr('action'),
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
			beforeSend: function(){
				$("#error_list").html('');
			},
            success:function(data){
				var returndata = JSON.parse(data);
				
                console.log("success");
                console.log(data);
				if(returndata.status=='SUCCESS'){
					alert(returndata.desc);
					window.location.href= "<?php echo base_url(); ?>index.php/blog_list";
				}else{
					$("#error_list").html(returndata.desc);
				}
				
            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
        });
    }));

  
});
</script>